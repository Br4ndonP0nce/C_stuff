#include <iostream>
#include "Periodic_table.h"
#include "lsl.h"
#include "Elemento.h"
int main() {
        TablaPeriodica* tp = new TablaPeriodica();
        tp->menu();
        return 0;
}